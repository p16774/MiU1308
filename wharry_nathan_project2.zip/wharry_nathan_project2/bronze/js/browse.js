// JavaScript Document

/*

*********************
Author: Nathan Wharry
Title: Project 2 - D&D Character Sheet - Browse Javascript
Term: MiU 1308
*********************

*/

// Wait for DOM to fully load
window.addEventListener("DOMContentLoaded", function() {
	
	// Browse by Name
	function browseName() {
		
		alert("This is browsing by name");
		
	};
	
	
	
	
	
	
	


}); // end Wait For Page to Load function